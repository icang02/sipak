<footer>
  <div class="footer clearfix mb-0 text-muted">
    <div class="float-start">
      <p>{{ date('Y') }} &copy; copyright</p>
    </div>
    <div class="float-end">
      <p>Made with <span class='text-dark'>by</span> <a href="#">BKKBN Prov.
          Sultra</a></p>
    </div>
  </div>
</footer>
